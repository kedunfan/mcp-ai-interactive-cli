import subprocess
import time
import threading
import sys
import os
import signal
from flask import Flask, request, jsonify
import queue

app = Flask(__name__)

# 全局变量
powershell_process = None
output_queue = queue.Queue()
read_thread = None
is_reading = False
process_lock = threading.Lock()

def read_powershell_output(proc):
    """在后台线程中读取PowerShell输出"""
    global is_reading
    while is_reading and proc and proc.poll() is None:
        try:
            # 非阻塞读取输出
            line = proc.stdout.readline()
            if line:
                # 尝试多种编码
                decoded_line = None
                for encoding in ['utf-8', 'gbk', 'gb2312', 'cp936']:
                    try:
                        decoded_line = line.decode(encoding, errors='strict')
                        break
                    except UnicodeDecodeError:
                        continue
                
                if decoded_line is None:
                    decoded_line = line.decode('utf-8', errors='ignore')
                
                # 移除可能的回车符和换行符
                cleaned_line = decoded_line.rstrip('\r\n')
                # 跳过空行和PowerShell提示符
                if cleaned_line and not cleaned_line.startswith('PS '):
                    # 存储输出，限制队列大小
                    if output_queue.qsize() > 100:
                        try:
                            output_queue.get_nowait()
                        except queue.Empty:
                            pass
                    output_queue.put(cleaned_line)
        except:
            pass
        time.sleep(0.1)

def start_powershell():
    """启动PowerShell进程"""
    global powershell_process, read_thread, is_reading
    
    with process_lock:
        if powershell_process and powershell_process.poll() is None:
            powershell_process.terminate()
            powershell_process.wait()
        
        # PowerShell 7 路径
        pwsh_path = r'C:\Program Files\PowerShell\7\pwsh.exe'
        
        # 如果指定路径不存在，尝试默认路径
        if not os.path.exists(pwsh_path):
            pwsh_path = 'pwsh.exe'
        
        try:
            # 创建PowerShell进程
            powershell_process = subprocess.Popen(
                [pwsh_path, '-NoExit'],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=False,
                bufsize=1
            )
            
            # 清空队列
            while not output_queue.empty():
                output_queue.get()
            
            # 启动读取线程
            is_reading = True
            read_thread = threading.Thread(target=read_powershell_output, args=(powershell_process,))
            read_thread.daemon = True
            read_thread.start()
            
            return True
        except Exception as e:
            print(f"启动PowerShell失败: {e}")
            return False

def execute_command(cmd):
    """执行命令并获取输出"""
    global powershell_process
    
    with process_lock:
        if not powershell_process or powershell_process.poll() is not None:
            if not start_powershell():
                return "错误: 无法启动PowerShell进程"
        
        try:
            # 清空之前的输出
            while not output_queue.empty():
                output_queue.get()
            
            # 自动为某些命令添加Out-String以提高兼容性
            processed_cmd = cmd
            cmd_lower = cmd.lower()
            
            # 如果是查询类命令且没有管道操作，自动添加Out-String
            if ('get-childitem' in cmd_lower or 'dir' in cmd_lower or 
                'ls' in cmd_lower or 'select-object' in cmd_lower or
                'where-object' in cmd_lower) and '|' not in cmd_lower and 'out-string' not in cmd_lower:
                processed_cmd = cmd + ' | Out-String'
            
            # 发送命令
            cmd_with_newline = processed_cmd + '\n'
            powershell_process.stdin.write(cmd_with_newline.encode('utf-8'))
            powershell_process.stdin.flush()
            
            # 根据命令类型调整等待时间
            if 'dir' in cmd_lower or 'get-childitem' in cmd_lower:
                wait_time = 2
            elif 'ping' in cmd_lower:
                wait_time = 5
            elif 'compile' in cmd_lower or 'build' in cmd_lower or 'make' in cmd_lower:
                wait_time = 10  # 编译命令需要更长时间
            else:
                wait_time = 3
            
            time.sleep(wait_time)
            
            # 收集输出
            output_lines = []
            while not output_queue.empty():
                try:
                    line = output_queue.get_nowait()
                    # 进一步清理输出
                    if line and not line.startswith('PS ') and '>' not in line:
                        # 移除可能的控制字符
                        cleaned_line = line.replace('\x00', '').replace('\r', '').replace('\x0c', '')
                        output_lines.append(cleaned_line)
                except queue.Empty:
                    break
            
            # 取最后50行
            result = '\n'.join(output_lines[-50:]) if output_lines else "无输出"
            return result
            
        except Exception as e:
            return f"执行命令时出错: {e}"

@app.route('/execute', methods=['POST'])
def execute():
    """处理命令执行请求"""
    data = request.json
    if not data or 'command' not in data:
        return jsonify({'error': '缺少命令参数'}), 400
    
    command = data['command']
    
    if command == '新建终端':
        if start_powershell():
            return jsonify({'output': '新的PowerShell终端已创建'})
        else:
            return jsonify({'output': '创建终端失败'}), 500
    
    output = execute_command(command)
    return jsonify({'output': output})

@app.route('/health', methods=['GET'])
def health():
    """健康检查"""
    if powershell_process and powershell_process.poll() is None:
        return jsonify({'status': 'running'})
    return jsonify({'status': 'stopped'}), 500

def cleanup(signum=None, frame=None):
    """清理资源"""
    global is_reading, powershell_process
    
    is_reading = False
    
    if read_thread and read_thread.is_alive():
        read_thread.join(timeout=1)
    
    if powershell_process and powershell_process.poll() is None:
        powershell_process.terminate()
        powershell_process.wait()
    
    print("\n清理完成，退出程序")
    sys.exit(0)

if __name__ == '__main__':
    # 注册信号处理
    signal.signal(signal.SIGINT, cleanup)
    signal.signal(signal.SIGTERM, cleanup)
    
    # 启动时自动创建PowerShell进程
    if start_powershell():
        print("PowerShell进程已启动")
    else:
        print("警告: PowerShell进程启动失败")
    
    print("终端接收机正在监听端口 5000...")
    print("使用 Ctrl+C 停止服务")
    
    # 启动Flask服务
    app.run(host='0.0.0.0', port=5000, debug=False)
