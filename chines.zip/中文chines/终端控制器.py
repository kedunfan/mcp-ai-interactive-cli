import sys
import requests
import json
import argparse

def send_command(server_url, command):
    """发送命令到服务器"""
    try:
        response = requests.post(
            f'{server_url}/execute',
            json={'command': command},
            timeout=10
        )
        
        if response.status_code == 200:
            data = response.json()
            return data.get('output', '无输出')
        else:
            return f"请求失败: {response.status_code}"
            
    except requests.exceptions.RequestException as e:
        return f"连接服务器失败: {e}"
    except json.JSONDecodeError:
        return "服务器返回了无效的响应"

def main():
    parser = argparse.ArgumentParser(description='远程终端控制器')
    parser.add_argument('command', nargs='+', help='要执行的命令（用引号括起来）')
    parser.add_argument('--server', default='http://localhost:5000', 
                       help='服务器地址，默认为 http://localhost:5000')
    
    args = parser.parse_args()
    
    # 合并命令参数
    command = ' '.join(args.command)
    server_url = args.server.rstrip('/')
    
    # 发送命令
    result = send_command(server_url, command)
    
    # 输出结果
    print("=" * 50)
    print(f"命令: {command}")
    print("-" * 50)
    print(f"输出:{result}")
    print("=" * 50)

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("使用方法:")
        print("  python 终端控制器.py \"想要执行的命令\"")
        print("  python 终端控制器.py 新建终端")
        print("  python 终端控制器.py --server http://远程服务器IP:5000 \"命令\"")
        sys.exit(1)
    
    main()